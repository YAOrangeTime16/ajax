//API for poker solver installed by npm
// https://github.com/goldfire/pokersolver
var Hand = require('pokersolver').Hand;

